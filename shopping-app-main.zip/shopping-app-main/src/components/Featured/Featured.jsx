import FeaturedLogic from "./FeaturedLogic";
const Featured = () => {
  
  return (
    <FeaturedLogic/>
  );
};

export default Featured;
