import TopRatedLogic from "./TopRatedLogic"

const TopRated = () => {
   
  return (
    <TopRatedLogic/>
  )
}

export default TopRated